# Evolutionary Strategies for Domain Adaptation

To train a general model on a source data set we need a lot of label samples this extensive amount of information isn't generally promptly accessible.  One way to deal with getting around this is utilizing information that has comparable highlights or understands the features of the data from the space the model is anticipated. By Apply this model to a target data set which is generated from a different distribution or a variety of other domain space. so that the model can pick up only the required features from the provided domain and try to predict the same features from an unseen new foreign unseen domain and perform same accurately as seen on the previous domain.This paper shows an approach of utilizing domain adaptation to prepare a deep neural network to recognize features that are domain pertinent using a widespread example of the artificially made dataset and a few example of data from the objective domain.This can be created by combining a feature extractor feed forward to a label predictor and using a domain classifier which can generate domain-invariant features and adapt to the target data











BSR_bsds500.tgz @
https://drive.google.com/file/d/1T8B6Gg13eEzBLYiOn9eAnOtXGugJUJV-/view?usp=sharing

MNIST-m data mnistm_data.pkl @
https://drive.google.com/file/d/1xniSxOfkWou-65m20Q_mUP6OqjrPSUIK/view?usp=sharing
